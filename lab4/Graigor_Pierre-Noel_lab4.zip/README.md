name: Graigor Pierre-Noel



The API I chose to utilize is the Runescape API which lets me query information on items.
It currently returns item information on a submitted item code or item name. Note that it will only work
for valid item codes or complete item names (i.e. it does not do search suggestion or anything of the like). Below I will put
a list of valid codes and names of items to test. IDs range from single digits to 13,000. Take a guess and it might be a valid item ID.

The API is very easy to use; it also offers graph information and category searching but I did not implement those.
I've followed the assignment outline and have bootstrap, media queries, and Angular. Like in the 
Angular example, my lab is a single page view. I do like how it is able to refresh within a single page.

The only difficulty I had with media queries was just understanding the syntax with it and correctly implementing it into
the lab. 



Names:
    prayer potions(1)
    shark
    shrimps
    cannonball
    super defence(2)
    eye of newt
    soul rune
    bones
    pike
    rune armour set
    jar of swamp

IDs
    350
    339
    257
    243
    319
    1109
    1069
    1265
    2187
    2205
    2434
    8437
    8008
    10047
    13036
    13109
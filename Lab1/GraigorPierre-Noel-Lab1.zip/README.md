name: Graigor Pierre-Noel
rcsid: pierrg

Lab was mostly done today but a lot of progress was made today. Sorry for being a little over ~half an hour late. I could not figure out for the life of my as to why my tweet texts weren't flowing past one line. Really peculiar but if I had a little more time. hopefully I could have figured it out. Below are some resources I used in addition to the bootstrap template I found online.

http://getbootstrap.com/components/#list-group
w3schools.com (for small explicit questions)
http://stackoverflow.com/questions/2813653/can-an-element-have-both-an-id-and-a-class
http://jsfiddle.net/yw8uZ/195/

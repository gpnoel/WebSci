name: Graigor Pierre-Noel


Things I ran into:
- List vs list spelling from openweather's API
- dealing with the api and trying to get the GET request all right was annoying
- deciding on my bootrstrap layout 
- getting a certificate setup then I eventuall just spun up a local server with Python to make my life easier

I did learn a lot from this lab and I do understand more how GET requests work and what kind of information you can pull and play with.
Name: Graigor Pierre-Noel

This lab wasn't too bad except for the main chunk of this lab. I knew about paths with express but
I had to look up how to get parameters from the get request. Honestly, the API for twitter streaming 
was absoulte garbage for its documentation. Didn't help that there weren't too any examples as well (especially
for the location filtering). That was the most frustrating part of this lab. This was the first time I worked with
sockets so tha was interesting to setup....luckily there was some guidance from the chat server example.

Now that I'm done with this lab, its interesting and nice to see everything work together.

To run the file, you can do `node server.js` or `npm start`.